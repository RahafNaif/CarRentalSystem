
public class NegtiveOrZeroNumberException extends Exception{

	public NegtiveOrZeroNumberException() {
			}

}
