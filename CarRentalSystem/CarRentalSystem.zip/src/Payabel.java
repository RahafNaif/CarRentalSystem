public interface Payabel {
	
    String printBill(int days);
    
}
